document.addEventListener('DOMContentLoaded', () => {
    console.log("Jalwa Game landing page loaded successfully!");
});
